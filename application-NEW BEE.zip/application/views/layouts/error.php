<div class="container-fluid py-5 text-center">
<h1 class="display-4">Kaca</h1>
    <blockquote class="blockquote text-center">
        <p class="mb-0">Halaman tidak ditemukan.</p>
        <footer class="blockquote-footer">Mungkin halaman yang anda cari <cite title="Source Title">rusak</cite></footer>
    </blockquote>
    <a onclick="goBack()" class="btn btn-dark btn-sm text-white">Kembali kehalaman sebelumnya</a>
</div>